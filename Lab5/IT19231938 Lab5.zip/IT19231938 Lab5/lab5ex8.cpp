//IT19231938
//K A K Kavinda
//WD_2021Jan/ Pro-rata

//This Program to print this pattern 1,2,4,5,6
#include <iostream>
using namespace std;
int main()
{
    int q = 1;
    do
    {
        if(q !=3){
            cout <<q <<endl;
        }
        q++;
    } while (q <= 6);
    
}