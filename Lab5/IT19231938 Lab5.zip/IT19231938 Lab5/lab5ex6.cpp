//IT19231938
//K A K Kavinda
//WD_2021Jan/ Pro-rata

//print My Name and Date of Birth using Do While
#include <iostream>
using namespace std;
int main()
{
    int q = 0;
    do
    {
        cout<< "Name : Kasun Kavinda"<<endl;
        cout<< "Birthday : 1999-08-06"<<endl;
        
        q++;
    } while (q < 3);
    
}