//IT19231938
//K A K Kavinda
//WD_2021Jan/ Pro-rata

//This Program to display 1 to 20
#include <iostream>
using namespace std;
int main()
{
    for(int i =1; i<=20; i++){
        cout<<i<<endl;
    }
    return 0;
}