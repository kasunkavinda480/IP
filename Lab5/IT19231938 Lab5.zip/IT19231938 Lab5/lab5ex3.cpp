//IT19231938
//K A K Kavinda
//WD_2021Jan/ Pro-rata

//This Program to print  the  Total  of  1  to  10  using  for-loop structure
#include <iostream>
using namespace std;
int main()
{
    int sum =0;
    for(int i =1; i<=10; i++){
        sum += i;
    }
    cout<<"Sum Is = "<<sum<<endl;
    return 0;
}