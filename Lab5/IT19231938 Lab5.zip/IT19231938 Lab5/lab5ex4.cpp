//IT19231938
//K A K Kavinda
//WD_2021Jan/ Pro-rata

//print  “Welcome to  SLIIT” ten  times  using while-loop
#include <iostream>
using namespace std;
int main()
{
    int no = 10;
    while (no > 0)
    {
        cout<< "Welcome to SLIIT" << endl;
        no = no -1;
    }
    return 0;
}