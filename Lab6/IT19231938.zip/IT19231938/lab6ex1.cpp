//IT19231938
//K A Kasun Kavinda
#include <iostream>
using namespace std;

void drawLines() {
    cout<<"**********"<<endl;
}

int main()
{
    drawLines();
    drawLines();
    drawLines();
    drawLines();
    return 0;
}