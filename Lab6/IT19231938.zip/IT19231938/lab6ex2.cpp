//IT19231938
//K A Kasun Kavinda
#include <iostream>
using namespace std;

void drawLinesWithRow(int rows) {
    for(int a=0; a < rows; a++){
        cout<<"**********"<<endl;
    }
    
}

int main()
{
    int i = 3;
    drawLinesWithRow(i);
    return 0;
}